import subprocess
import time
subprocess.call("adb root",shell=True)
subprocess.call("adb install app-pressure.apk",shell=True)
print("launching the sensor activity of Application")
time.sleep(5)
subprocess.call("adb shell am start -n com.example.test_pressure/com.example.test_pressure.MainActivity",shell=True)
time.sleep(10)
subprocess.call("adb pull /data/data/com.example.test_pressure/files/eInfochips/Alt_Results.csv",shell=True)

print("Process done Sucessfully !!! ")


