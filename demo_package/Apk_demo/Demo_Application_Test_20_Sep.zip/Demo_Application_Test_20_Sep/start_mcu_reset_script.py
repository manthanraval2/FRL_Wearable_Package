import subprocess
import time
import json

subprocess.call("adb root",shell=True)
subprocess.call("adb push mcu_reset.sh /data/local/tmp/.",shell=True)
subprocess.call("adb shell chmod 777 /data/local/tmp/mcu_reset.sh",shell=True)                          

print("Start MCU reset script.....")
subprocess.call("adb shell sh ./data/local/tmp/mcu_reset.sh &",shell=True)
sub.communicate()